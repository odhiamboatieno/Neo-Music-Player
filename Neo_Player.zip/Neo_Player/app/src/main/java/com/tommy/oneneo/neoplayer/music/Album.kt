package com.tommy.oneneo.neoplayer.music

data class Album(
    val title: String,
    val year: String
)